package collections;

public class Hash_Table_Basics {
// same as hashmap only diff it is synchronized and has no null keys or values
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
