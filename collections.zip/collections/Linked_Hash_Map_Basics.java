package collections;
import java.util.*;
// exact same as hash map except for the fact that it maintains insertion order
@SuppressWarnings("unused")
public class Linked_Hash_Map_Basics {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
