package multithreading;
public class Printer {
public void print(String s)
{
	for(int i=1;i<=10;i++)
		System.out.println(s+" "+i);
}
}
