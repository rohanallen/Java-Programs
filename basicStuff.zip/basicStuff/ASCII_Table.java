package basicStuff;
//Write a Java Program to print ASCII Table.
public class ASCII_Table {
public static void main(String[] args) {
for(int i=0;i<=255;i++)
{
	System.out.println("The ASCII value of "+(char)i+" is "+i+".");
}
}
}
