package basicStuff;
public class System_Time {
	  
	  public static void main(String[] args){
	         System.out.format("\nCurrent Date time: %tc%n\n", System.currentTimeMillis());
	    }
	}
