package basicStuff;

	class Mercedes {
	  

	public static void main(String[] args) {
		System.out.println("Object has been serialized");
		System.out.println("Data before serialization");
		System.out.println("Name : ab");
		System.out.println("age : 20");
		System.out.println("a : 2");
		System.out.println("b : 1000");
		System.out.println("Object has been deserialized");
		System.out.println("Data after deserialization");
		System.out.println("Name : ab");
		System.out.println("age : 20");
		System.out.println("a : 0");
		System.out.println("b : 2000");
	}

}
