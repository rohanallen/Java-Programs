package basicStuff;
/*Java StringBuilder class is used to create mutable (modifiable) 
 * string. The Java StringBuilder class is same as StringBuffer
 *  class except that it is non-synchronized.
 *  StringBuilder is non-synchronized i.e. not thread safe.
 *   It means two threads can call the methods of StringBuilder
 *    simultaneously*/
import java.util.*;
@SuppressWarnings("unused")
public class String_Builder_Class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	// understood everything except capacity method
		
		// exact same as string buffer class only difference the methods are non synchronized(multiple threads can access at same time to increase speed and performance)
		
		// Read Priya G notes
	}

}
