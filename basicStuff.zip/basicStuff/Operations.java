package basicStuff;

public class Operations {

	public static void main(String[] args) {
		System.out.println(5>>1);

	}

}
