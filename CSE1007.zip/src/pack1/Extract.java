package pack1;
public class Extract {
public int a[] = new int[10];
public int l,digit;
public void extractDigits(int n)
{
	int i=0;
	while(n!=0)
	{
		digit=n%10;
		a[i]=digit;
		n=n/10;
		i++;
		
	}
	l=i;
}
}
