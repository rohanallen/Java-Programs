package pack1.pack2;
import pack1.Extract;
@SuppressWarnings("unused")
public class SumOfSquares extends Sum {
public int square_result;
	public void printSumofSquares()
	{
		square_result=0;
		for(int i=0;i<l;i++)
		{
			square_result=square_result+(a[i]*a[i]);
		}
		System.out.println("Sum of Digits Squared is "+square_result);
	}
	
}
