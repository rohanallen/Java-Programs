package pack1.pack2;
import pack1.Extract;
public class Sum extends Extract {
public int sum_result;
public void printSum()
{
	sum_result=0;
	for(int i=0;i<l;i++)
	{
		sum_result=sum_result+a[i];
	}
	System.out.println("Sum of Digits is "+sum_result);
}
}
