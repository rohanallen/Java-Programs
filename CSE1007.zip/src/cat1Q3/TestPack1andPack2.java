package cat1Q3;
/*Create a package named Pack1, with a class �Extract�. Create another package 
Pack2 inside Pack1 with two classes �Sum� and �SumOfSquares� in it.        (10M) 

                            
a. In the �Extract� class, define a method extractDigits() that will extract
the digits of a number passed to it and store the extracted digits in an array. 
b. In the �Sum� class, define a method printSum() to find the sum of the  elements 
of the array stored in �Extract� class. 
c. In the �SumOfSquares� class, define a method printSumofSquares() to find
the sum of the squares of the array elements
d. Define the main class and import the packages and call the methods
under the classes Extract, Sum, SumOfSquares respectively.                        
*/

import pack1.*;

import pack1.pack2.*;
import java.util.*;
@SuppressWarnings("unused")
public class TestPack1andPack2 {
public static void main(String[] args)
{
@SuppressWarnings("resource")
Scanner in = new Scanner(System.in);
System.out.println("Enter 10 Digit Number");
int n = in.nextInt();
SumOfSquares obj = new SumOfSquares();
obj.extractDigits(n);
obj.printSum();
obj.printSumofSquares();



}
}
