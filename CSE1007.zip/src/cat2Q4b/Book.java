package cat2Q4b;
/*b)	Create a map object for storing the book access number and its 
 * title. Use Lambda expression to display all the book entries in the map 
 * object related to Java.                                         (5)*/
import java.util.*;

interface A{
	public void print();// one abstract method
}
public class Book {
	public static void main(String[] args) {
		HashMap<Integer,String> map = new HashMap<Integer,String>();
		map.put(1,"Java Programming");
		map.put(2,"Java Engineering");
		map.put(3,"Java FX");
		map.put(4,"C++");
		map.put(5,"Python");
		map.put(6,"JavaScript");
		// start of lambda expression
		// obj is object of interface A
		A obj=()->{
		for(Map.Entry<Integer,String> m:map.entrySet())
		{
			if(m.getValue().contains("Java"))// string function contains returns true
			{
				System.out.println(m.getKey()+"  "+m.getValue());
			}
		}
		};// print function implementation
		obj.print();

	}

}
