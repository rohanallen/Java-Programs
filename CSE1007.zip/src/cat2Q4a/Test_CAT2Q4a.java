package cat2Q4a;
import java.util.*;
public class Test_CAT2Q4a {
	public static void main(String[] args) {
	@SuppressWarnings("resource")
	Scanner in = new Scanner(System.in);
	// creating hashmap map to store key as integer and value as object of class
	HashMap<Integer,Indian_Cricket> map = new HashMap<Integer,Indian_Cricket>();
	Indian_Cricket obj = new Indian_Cricket("Kohli");// create an object if type class
	Indian_Cricket obj1 = new Indian_Cricket("Dhoni");
	Indian_Cricket obj2 = new Indian_Cricket("Samson");
	map.put(1,obj);
	map.put(2,obj1);// add the integer key plus object value
	map.put(3,obj2);
	System.out.println("Enter Player Name");
	String s = in.nextLine();
	for(Map.Entry<Integer,Indian_Cricket> m : map.entrySet()) {// traverse thru map
		Indian_Cricket player = m.getValue();// get value(player) which is of type object whereas player.name is a string
        if(player.name.equals(s))  // if value in map equals input  
        {                          
              System.out.println("Key of "+player.name+" is "+m.getKey());// print that key
        }
      }
	}
	// We can also specify map as<Integer,String> and completely bypass creating objects

}
