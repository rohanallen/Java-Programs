/*Create a map object for storing names of Indian cricket team players. Read a player name     
                 from the user and search it in the Map object and display the key if the name is present.       (5)
*/
package cat2Q4a;
public class Indian_Cricket {
String name;
public Indian_Cricket(String name)// constructor
{
	this.name=name;
}
}
