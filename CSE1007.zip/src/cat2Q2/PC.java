package cat2Q2;
import java.util.*;
public class PC {
int limit;
public PC(int limit)
{
	this.limit=limit;
}
ArrayList<String> ar = new ArrayList<String>();
synchronized void produce()
{
	while(ar.size()==limit)
	{
		try {
			wait();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
	@SuppressWarnings("resource")
	Scanner in = new Scanner(System.in);
	System.out.println("Inputing Value from: "+Thread.currentThread().getName());
	String s = in.nextLine();
	if(s.equals("stop"))
		System.exit(0);
	else
	{
		ar.add(s);
	}
		notify();
}
synchronized String consume()
{
	notify();
	while(ar.size()==0)
	{
		try {
		wait();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	String data =ar.get(0);
	ar.remove(0);
	return data;
}
}
