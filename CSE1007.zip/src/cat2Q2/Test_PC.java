package cat2Q2;
import java.util.*;
public class Test_PC {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		System.out.println("Welcome to Producer Consumer Problem");
		System.out.println("Input Size of Buffer");
		int n = in.nextInt();
		PC obj = new PC(n);
		Producer_Thread p1 = new Producer_Thread(obj);
		Consumer_Thread c1 = new Consumer_Thread(obj);
		//Consumer_Thread c2 = new Consumer_Thread(obj);
		p1.setName("Producer 1");
		c1.setName("Consumer 1");
		//c2.setName("Consumer 2");
		
		// we can also use multiple consumers
		p1.start();
		c1.start();
		//c2.start();

	}

}
