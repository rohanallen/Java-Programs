package cat2Q2;
public class Producer_Thread extends Thread{
PC ref;
public Producer_Thread(PC ref)
{
	this.ref=ref;
}
public void run()
{
	while(true)
	{
		try
		{
		ref.produce();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
}

