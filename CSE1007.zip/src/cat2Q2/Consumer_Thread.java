package cat2Q2;

public class Consumer_Thread extends Thread {
	PC ref;
	public Consumer_Thread(PC ref)
	{
		this.ref=ref;
	}
	public void run()
	{
		try {
		while(true)
		{
			
			String s =ref.consume();
			System.out.println("Printed value by: "+Thread.currentThread().getName()+" is "+s);
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
