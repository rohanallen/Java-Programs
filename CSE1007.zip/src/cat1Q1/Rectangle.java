package cat1Q1;
public class Rectangle extends Shape {
	public void area()
	{
		area=l*b;
	}
	public void perimeter()
	{
		perimeter = 2*(l+b);
	}
	public void display()
	{
		System.out.println("Area of Rectangle is " + area+".");
		System.out.println("Perimeter of Rectangle is " + perimeter+".");

	}
}

