package cat1Q1;

/*Given the following hierarchy   (10M)                   
                    Shape


Circle   Rectangle    Triangle    Square
Base class Shape has a data member �result� of type double.
 Include abstract methods area (), perimeter () and display ().
  Classes Circle, Rectangle, Triangle, Square are subclasses to Shape. 
  Include data members in subclass if necessary. Override the member functions 
  area and perimeter in respective subclasses. Use Dynamic polymorphism to find the
   area and perimeter for each subclass.  */

import java.util.*;
abstract public class Shape {
	double area,perimeter;
	static double l;/*static is used as these variables are being inputed by user and 
	therefore cannot be changed like area and perimeter*/
	static double b;
	static double r;
	static double base,height,side1,side2,side;
	// instance variables (accessible to everyone)
	abstract public void area();
	abstract public void perimeter();
	abstract public void display();
	//main method
	public static void main(String[] args)
	{
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		System.out.println("Welcome to my Program");
		Shape obj = new Circle();
		// we use upcasting here so that we only have to create one super class reference
		System.out.println("Enter Radius of Circle");
		r = in.nextDouble();
		obj.area();
		obj.perimeter();
		obj.display();
		obj = new Rectangle();/* use same super class reference(obj) everywhere as main objective
		of function overriding is the ability of one object to take on many forms*/
		System.out.println("Enter Length of Rectangle");
		l = in.nextDouble();
		System.out.println("Enter Breadth of Rectangle");
		b = in.nextDouble();
		obj.area();
		obj.perimeter();
		obj.display();
		obj = new Triangle();// use same obj everywhere
		System.out.println("Enter Height of Triangle");
		height = in.nextDouble();
		System.out.println("Enter Base of Triangle");
		base = in.nextDouble();
		System.out.println("Enter Side1 of Triangle");
		side1 = in.nextDouble();
		System.out.println("Enter Side2 of Triangle");
		side2 = in.nextDouble();
		obj.area();
		obj.perimeter();
		obj.display();
		obj = new Square();// use same obj everywhere
		System.out.println("Enter Side of Square");
		side = in.nextDouble();
		obj.area();
		obj.perimeter();
		obj.display();

	}


}
