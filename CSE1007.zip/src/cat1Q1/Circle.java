package cat1Q1;
public class Circle extends Shape {
	public void area()
	{
		area=(Math.PI)*r*r;
	}
	public void perimeter()
	{
		perimeter = 2*(Math.PI)*r;
	}
	public void display()
	{
		System.out.println("Area of Circle is " + area+".");
		System.out.println("Perimeter of Circle is " + perimeter+".");

	}
}

