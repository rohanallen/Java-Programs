package cat1Q1;
public class Triangle extends Shape {
	public void area()
	{
		area=(0.5)*base*height;
	}
	public void perimeter()
	{
		perimeter = side1+side2+base;
	}
	public void display()
	{
		System.out.println("Area of Triangle is " + area+".");
		System.out.println("Perimeter of Triangle is " + perimeter+".");

	}	
}


