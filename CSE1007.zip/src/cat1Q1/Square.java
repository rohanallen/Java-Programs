package cat1Q1;
public class Square extends Shape {
	public void area()
	{
		area=side*side;
	}
	public void perimeter()
	{
		perimeter = 4*side;
	}
	public void display()
	{
		System.out.println("Area of Square is " + area+".");
		System.out.println("Perimeter of Square is " + perimeter+".");

	}
}

