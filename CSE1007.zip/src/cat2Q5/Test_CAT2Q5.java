package cat2Q5;

import java.util.*;

public class Test_CAT2Q5 {

	public static void main(String[] args) {
		ArrayList<Student> ar = new ArrayList<Student>();
		Student obj = new Student(1,"Rohan",9);
		Student obj1 = new Student(2,"Rohit",3.9);// creating student object
		Student obj2 = new Student(3,"Ryan",2.5);
		Student obj3 = new Student(4,"Rahul",2);
		Student obj4 = new Student(5,"Vijay",8.4);
		ar.add(obj);// adding student objects to arraylist
		ar.add(obj1);
		ar.add(obj2);
		ar.add(obj3);
		ar.add(obj4);
		//lam is object of interface A
		A lam=()->{
			Iterator<Student> itr = ar.iterator();// to iterate
			while(itr.hasNext())
			{
				Student s= itr.next();
				if(s.CGPA<4.0)// of double value
				{
					System.out.println(s.Stu_id+" "+s.Name+" "+s.CGPA);
				}
				
			}
		};// implementation of display method
		lam.display();
	}

}
