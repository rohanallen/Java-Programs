package cat2Q5;
/*Write a lambda expression to iterate the objects 
 * (at least five objects) of Student class 
 *   (Stu_id, Name, CGPA) stored in an ArrayList collection object 
 *   and display only the student details whose CGPA is less than 4.                                                                      (6)*/
interface A
{
	public void display();
}
public class Student {
	int Stu_id;
	String Name;
	double CGPA;
public Student(int Stu_id,String Name,double CGPA)
{
	this.Stu_id=Stu_id;
	this.Name=Name;
	this.CGPA=CGPA;
}

}
