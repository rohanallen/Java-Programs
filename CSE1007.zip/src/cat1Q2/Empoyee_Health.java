package cat1Q2;
import java.util.Scanner;
public class Empoyee_Health implements BMI  {
String name;
int age;
double height,weight,bmi;
boolean diabetic;
//instance variables
@SuppressWarnings("resource")
Scanner in = new Scanner(System.in);
void input()
{
	System.out.println("Enter Name");
	name=in.nextLine();
	System.out.println("Enter Age");
	age=in.nextInt();
	System.out.println("Enter Height in meteres");
	height=in.nextDouble();
	System.out.println("Enter Weight in kg");
	weight=in.nextDouble();
}
public void calculateBMI()//overriding
{
	bmi = weight/(height*height);
	System.out.println(name+" has BMI of "+bmi);
}
void fittest()
{
	if(bmi>18.5&&bmi<25)
	{
		System.out.println(name+" has Normal BMI and is fit.");
	}
	else
	{
		System.out.println(name+" does not have Normal BMI and is not fit.");
	}
}
public static void main(String[] args)
{
	@SuppressWarnings("resource")
	Scanner in = new Scanner(System.in);
	System.out.println("Enter Number of Employees");
	int n = in.nextInt();
	Empoyee_Health emp[]=new Empoyee_Health[n];// array of objects
	for(int i=0;i<n;i++)
	{
		emp[i]=new Empoyee_Health();// creating object of first employee
		emp[i].input();
		emp[i].calculateBMI();
		emp[i].fittest();
	}
	
	
	
	
}

	
}



