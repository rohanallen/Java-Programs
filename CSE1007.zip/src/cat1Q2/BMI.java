package cat1Q2;
/* Given a class Employee_Health, with data members, name, age, 
height, weight, diabetic (Boolean). Create an interface BMI with an 
abstract method Calculate_BMI(). (use BMI=Weight/(Height*Height) kg/m2(10M)
a.	Implement the interface with class Employee_Health.
b.	Create an array of objects to maintain the health information of n employees.
c.	Use method Input () to get the values of an employee. 
d.	Define Calculate_BMI () inside Employee_Health to get the BMI of an employee.
e.	Write the method Fittest () to identify and print the employee information with
Normal BMI and no diabetics. BMI is normal if the value falls between18.5 to 25.  */ 

public interface BMI {
void calculateBMI();
}
